gdjs.Untitled_32scene3Code = {};
gdjs.Untitled_32scene3Code.GDambuObjects1= [];
gdjs.Untitled_32scene3Code.GDambuObjects2= [];
gdjs.Untitled_32scene3Code.GDNewTextObjects1= [];
gdjs.Untitled_32scene3Code.GDNewTextObjects2= [];
gdjs.Untitled_32scene3Code.GDNewSpriteObjects1= [];
gdjs.Untitled_32scene3Code.GDNewSpriteObjects2= [];

gdjs.Untitled_32scene3Code.conditionTrue_0 = {val:false};
gdjs.Untitled_32scene3Code.condition0IsTrue_0 = {val:false};
gdjs.Untitled_32scene3Code.condition1IsTrue_0 = {val:false};
gdjs.Untitled_32scene3Code.condition2IsTrue_0 = {val:false};


gdjs.Untitled_32scene3Code.mapOfGDgdjs_46Untitled_9532scene3Code_46GDNewSpriteObjects1Objects = Hashtable.newFrom({"NewSprite": gdjs.Untitled_32scene3Code.GDNewSpriteObjects1});
gdjs.Untitled_32scene3Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Untitled_32scene3Code.GDNewSpriteObjects1);

gdjs.Untitled_32scene3Code.condition0IsTrue_0.val = false;
gdjs.Untitled_32scene3Code.condition1IsTrue_0.val = false;
{
gdjs.Untitled_32scene3Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Untitled_32scene3Code.condition0IsTrue_0.val ) {
{
gdjs.Untitled_32scene3Code.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Untitled_32scene3Code.mapOfGDgdjs_46Untitled_9532scene3Code_46GDNewSpriteObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.Untitled_32scene3Code.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Untitled scene2", false);
}}

}


{


gdjs.Untitled_32scene3Code.condition0IsTrue_0.val = false;
{
gdjs.Untitled_32scene3Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Untitled_32scene3Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "Alarm The Alarms.ogg", true, 100, 3);
}}

}


};

gdjs.Untitled_32scene3Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32scene3Code.GDambuObjects1.length = 0;
gdjs.Untitled_32scene3Code.GDambuObjects2.length = 0;
gdjs.Untitled_32scene3Code.GDNewTextObjects1.length = 0;
gdjs.Untitled_32scene3Code.GDNewTextObjects2.length = 0;
gdjs.Untitled_32scene3Code.GDNewSpriteObjects1.length = 0;
gdjs.Untitled_32scene3Code.GDNewSpriteObjects2.length = 0;

gdjs.Untitled_32scene3Code.eventsList0(runtimeScene);
return;

}

gdjs['Untitled_32scene3Code'] = gdjs.Untitled_32scene3Code;
