gdjs.Untitled_32sceneCode = {};
gdjs.Untitled_32sceneCode.GDambuObjects1= [];
gdjs.Untitled_32sceneCode.GDambuObjects2= [];
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects1= [];
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects2= [];
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1= [];
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2= [];
gdjs.Untitled_32sceneCode.GDleftObjects1= [];
gdjs.Untitled_32sceneCode.GDleftObjects2= [];
gdjs.Untitled_32sceneCode.GDrightObjects1= [];
gdjs.Untitled_32sceneCode.GDrightObjects2= [];
gdjs.Untitled_32sceneCode.GDambucamObjects1= [];
gdjs.Untitled_32sceneCode.GDambucamObjects2= [];
gdjs.Untitled_32sceneCode.GDNewTextObjects1= [];
gdjs.Untitled_32sceneCode.GDNewTextObjects2= [];
gdjs.Untitled_32sceneCode.GDretryObjects1= [];
gdjs.Untitled_32sceneCode.GDretryObjects2= [];
gdjs.Untitled_32sceneCode.GDNewSprite2Objects1= [];
gdjs.Untitled_32sceneCode.GDNewSprite2Objects2= [];
gdjs.Untitled_32sceneCode.GDNewSprite3Objects1= [];
gdjs.Untitled_32sceneCode.GDNewSprite3Objects2= [];

gdjs.Untitled_32sceneCode.conditionTrue_0 = {val:false};
gdjs.Untitled_32sceneCode.condition0IsTrue_0 = {val:false};
gdjs.Untitled_32sceneCode.condition1IsTrue_0 = {val:false};
gdjs.Untitled_32sceneCode.condition2IsTrue_0 = {val:false};
gdjs.Untitled_32sceneCode.condition3IsTrue_0 = {val:false};


gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDambuObjects1Objects = Hashtable.newFrom({"ambu": gdjs.Untitled_32sceneCode.GDambuObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDNewSpriteObjects1Objects = Hashtable.newFrom({"NewSprite": gdjs.Untitled_32sceneCode.GDNewSpriteObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDleftObjects1Objects = Hashtable.newFrom({"left": gdjs.Untitled_32sceneCode.GDleftObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDrightObjects1Objects = Hashtable.newFrom({"right": gdjs.Untitled_32sceneCode.GDrightObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDretryObjects1Objects = Hashtable.newFrom({"retry": gdjs.Untitled_32sceneCode.GDretryObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDambuObjects1Objects = Hashtable.newFrom({"ambu": gdjs.Untitled_32sceneCode.GDambuObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDNewSprite2Objects1Objects = Hashtable.newFrom({"NewSprite2": gdjs.Untitled_32sceneCode.GDNewSprite2Objects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDambuObjects1Objects = Hashtable.newFrom({"ambu": gdjs.Untitled_32sceneCode.GDambuObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDNewSprite3Objects1Objects = Hashtable.newFrom({"NewSprite3": gdjs.Untitled_32sceneCode.GDNewSprite3Objects1});
gdjs.Untitled_32sceneCode.eventsList0 = function(runtimeScene) {

{


gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Untitled_32sceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.Untitled_32sceneCode.GDNewTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("retry"), gdjs.Untitled_32sceneCode.GDretryObjects1);
{gdjs.evtTools.sound.playSound(runtimeScene, "S.ogg", true, 100, 1);
}{runtimeScene.getVariables().get("ambudead").setNumber(0);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDretryObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDretryObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewTextObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewTextObjects1[i].hide();
}
}}

}


{


gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
{
gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.logicalNegation(false);
}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("ambudead")) == 0;
}}
if (gdjs.Untitled_32sceneCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Untitled_32sceneCode.GDNewSpriteObjects1);
gdjs.copyArray(runtimeScene.getObjects("ambu"), gdjs.Untitled_32sceneCode.GDambuObjects1);
gdjs.copyArray(runtimeScene.getObjects("ambucam"), gdjs.Untitled_32sceneCode.GDambucamObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDambucamObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDambucamObjects1[i].addForce(0, -(500), 0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDambuObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDambuObjects1[i].addForce(0, -(500), 0);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].addForce(0, -(500), 0);
}
}}

}


{


gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.logicalNegation(false);
}if (gdjs.Untitled_32sceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ambucam"), gdjs.Untitled_32sceneCode.GDambucamObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Untitled_32sceneCode.GDambucamObjects1.length !== 0 ? gdjs.Untitled_32sceneCode.GDambucamObjects1[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Untitled_32sceneCode.GDNewSpriteObjects1);
gdjs.copyArray(runtimeScene.getObjects("ambu"), gdjs.Untitled_32sceneCode.GDambuObjects1);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDambuObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDNewSpriteObjects1Objects, false, runtimeScene, false);
}if (gdjs.Untitled_32sceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.Untitled_32sceneCode.GDNewTextObjects1);
/* Reuse gdjs.Untitled_32sceneCode.GDambuObjects1 */
gdjs.copyArray(runtimeScene.getObjects("retry"), gdjs.Untitled_32sceneCode.GDretryObjects1);
{runtimeScene.getVariables().get("ambudead").setNumber(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "NewFile.wav", false, 100, 0.5);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDambuObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDambuObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDretryObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDretryObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewTextObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewTextObjects1[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("left"), gdjs.Untitled_32sceneCode.GDleftObjects1);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
{
gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDleftObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.Untitled_32sceneCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ambu"), gdjs.Untitled_32sceneCode.GDambuObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDambuObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDambuObjects1[i].addForce(-(400), 0, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("right"), gdjs.Untitled_32sceneCode.GDrightObjects1);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
{
gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDrightObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.Untitled_32sceneCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ambu"), gdjs.Untitled_32sceneCode.GDambuObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDambuObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDambuObjects1[i].addForce(400, 0, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("retry"), gdjs.Untitled_32sceneCode.GDretryObjects1);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = false;
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = false;
{
gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.Untitled_32sceneCode.condition0IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDretryObjects1Objects, runtimeScene, true, false);
}if ( gdjs.Untitled_32sceneCode.condition1IsTrue_0.val ) {
{
gdjs.Untitled_32sceneCode.condition2IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("ambudead")) == 1;
}}
}
if (gdjs.Untitled_32sceneCode.condition2IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Untitled scene", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite2"), gdjs.Untitled_32sceneCode.GDNewSprite2Objects1);
gdjs.copyArray(runtimeScene.getObjects("ambu"), gdjs.Untitled_32sceneCode.GDambuObjects1);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDambuObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDNewSprite2Objects1Objects, false, runtimeScene, false);
}if (gdjs.Untitled_32sceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.Untitled_32sceneCode.GDNewTextObjects1);
/* Reuse gdjs.Untitled_32sceneCode.GDambuObjects1 */
gdjs.copyArray(runtimeScene.getObjects("retry"), gdjs.Untitled_32sceneCode.GDretryObjects1);
{runtimeScene.getVariables().get("ambudead").setNumber(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "NewFile.wav", false, 100, 0.5);
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDambuObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDambuObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDretryObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDretryObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewTextObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewTextObjects1[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite3"), gdjs.Untitled_32sceneCode.GDNewSprite3Objects1);
gdjs.copyArray(runtimeScene.getObjects("ambu"), gdjs.Untitled_32sceneCode.GDambuObjects1);

gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.Untitled_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDambuObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_46Untitled_9532sceneCode_46GDNewSprite3Objects1Objects, false, runtimeScene, false);
}if (gdjs.Untitled_32sceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Untitled scene3", false);
}}

}


};

gdjs.Untitled_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32sceneCode.GDambuObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDambuObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTiledSpriteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDleftObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDleftObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDrightObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDrightObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDambucamObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDambucamObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDretryObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDretryObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite3Objects2.length = 0;

gdjs.Untitled_32sceneCode.eventsList0(runtimeScene);
return;

}

gdjs['Untitled_32sceneCode'] = gdjs.Untitled_32sceneCode;
